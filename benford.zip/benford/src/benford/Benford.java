package benford;

import java.util.Scanner;
import java.io.*;




public class Benford {
	
	//private static int int num1;
    public static int lines;
    public static int num5 =0;
    public static int num1=0;
	public static int num2=0;
	public static int num3 =0;
	public static int num4=0;
	//int num5=0;
	public static int num6=0;
	public static int num7=0;
	public static int num8=0;
	public static int num9 =0;
	public static void main (String[] args) throws IOException{
		
       String[] text = readarray("data.txt");
      
      
      doCalculation(text);
      System.out.println(lines); 
      System.out.print(num1);
       
	   	
	}
	
	public static String[] readarray (String file) throws IOException{
	    lines = 0;
		Scanner line = new Scanner(new File(file));
		while (line.hasNextLine()){
			lines++;
			line.next();
		}
		String[] numbers = new String[lines] ;
		
		Scanner line2 = new Scanner(new File(file));
		
			for(int i=0; i<lines;i++){
				numbers[i] = line2.next();
			}
		return numbers;
	}
	
	public static void doCalculation(String[] file){
	
		
		for ( int j=0; j< 10000 ; j++){
			
			
			 doChar(file[j]);
				
			
			//System.out.println();
		}
		
		//System.out.print(num1);
		

	}

	public static void doChar(String s){

		char[] a = s.toCharArray();
		/*for(int i=0;i<a.length;i++){
		    System.out.println("Data at ["+i+"]="+a[i]);
	    
		}*/
		boolean loop = true;
		int j = 0;
		while (loop ){
			if ( a[j] == '0'){
				j++;
			}
			else if (a[j] == 'E'){
				j++;
			}
			else if ( a[j] == '-'){
				j++;
			}
			else if (a[j] == '.'){
				j++;
			}
			else if (a[j] == '1'){
				num1++;
				loop = false;
			}
			else if (a[j] == '2'){
				num2++;
				loop = false;
			}
			else if (a[j] == '3'){
				num3++;
				loop = false;
			}
			else if (a[j] == '4'){
				num4++;
				loop = false;
			}
			else if (a[j] == '5'){
				num5++;
				loop = false;
			}
			else if (a[j] == '6'){
				num6++;
				loop = false;
			}
			else if (a[j] == '7'){
				num7++;
				loop = false;
			}
			else if (a[j] == '8'){
				num8++;
				loop = false;
			}
			else if (a[j] == '9'){
				num9++;
				loop = false;
			}
			else { loop = false;}
			
			
		}
		//System.out.print(num6);
		//System.out.print(num5);
		//System.out.print(num5);
		
	}
	

}
